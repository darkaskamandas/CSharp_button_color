﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace themes
{
    public partial class Form1 : Form
    {
        List<Control> panels;
        List<Control> buttons;
        List<Control> textboxes;
        public Form1()
        {
            InitializeComponent();
        }

        void Initialize_Add()
        {
            panels = new List<Control>();
            buttons = new List<Control>();
            textboxes = new List<Control>();

            panels.Add(panel1);
            panels.Add(panel2);

            buttons.Add(button1);
            buttons.Add(button2);
            buttons.Add(button3);

            textboxes.Add(textBox1);
            textboxes.Add(textBox2);
            textboxes.Add(textBox3);
            textboxes.Add(textBox4);
            textboxes.Add(textBox5);
        }

        void ApplyTheme(Color back,Color pan,Color btn, Color tbox, Color combox,Color TextColor)
        {
            this.BackColor = back;
            comboBox1.BackColor = combox;
            comboBox1.ForeColor = TextColor;

            foreach (Control item in panels)
            {
                item.BackColor = pan;
            }

            foreach (Control item in buttons)
            {
                item.BackColor = btn;
                item.ForeColor = TextColor;
            }

            foreach (Control item in textboxes)
            {
                item.BackColor = tbox;
                item.ForeColor = TextColor;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Initialize_Add();
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Light")
            {
                ApplyTheme(Color.White, zcolor(240, 240, 240), zcolor(181, 181, 181), zcolor(110, 110, 110), Color.White, Color.Black);
            }

            else if(comboBox1.Text == "Dark")
            {
                ApplyTheme(zcolor(30, 30, 30), zcolor(45, 45, 48), zcolor(104, 104, 104), zcolor(51, 51, 51), Color.Black, Color.White);
            }
        }

        Color zcolor(int r,int g, int b)
        {
           return Color.FromArgb(r, g, b);
        }
    }
}
